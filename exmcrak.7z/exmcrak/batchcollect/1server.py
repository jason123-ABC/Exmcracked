import os
import logging
import base64
import json
import click
from flask import Flask, request, abort

app = Flask(__name__)

log = logging.getLogger('werkzeug')
log.setLevel(logging.ERROR)

def secho(text, file=None, nl=None, err=None, color=None, **styles):
    pass

def echo(text, file=None, nl=None, err=None, color=None, **styles):
    pass

click.echo = echo
click.secho = secho

@app.route('/getfile', methods=['GET'])
def get_file():
    batch_id_base64 = request.headers.get('BatchID')
    if not batch_id_base64:
        return abort(400, description="Missing 'BatchID' header")

    try:
        batch_id = base64.b64decode(batch_id_base64).decode('utf-8')
    except (base64.binascii.Error, UnicodeDecodeError):
        return abort(400, description="Invalid base64 encoding")

    if not os.path.exists(batch_id):
        return abort(404, description="File not found")

    try:
        with open(batch_id, 'r') as file:
            
            content = file.read()
            contentjson = json.loads(content)
            print("\nBatchID: "+batch_id)
            print("BatchTitle: "+contentjson['batchTitle']+"\n")
        return content
    except Exception as e:
        return abort(500, description=str(e))

appHasRunBefore:bool = False

if __name__ == '__main__':
    print("Started Server")
    app.run(host='0.0.0.0', port=5001)